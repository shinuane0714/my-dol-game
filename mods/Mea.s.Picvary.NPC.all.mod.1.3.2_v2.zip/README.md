# Mea's Picvary NPC all mod (1.3.2)

※Important: Modloader required for loading this mod, check the link below for downloading:
            https://github.com/Lyoko-Jeremie/sugarcube-2-ModLoader

Further Info:
            https://github.com/Maenoko/Mae-s-Picvary-NPC-mod

This is my first time trying to make my own mod, there've being much troubles I met, but thanks to all my friends and other nice people from the community who are willing to offer help, I could finally make it out.

Now I've managed to include all the "love interest" characters and some other named NPCs in my mod, more are on the way :D.

Not sure how long could go, I will try my best.
If you find any bugs, please give me feedback about them.

Enjoy your play!