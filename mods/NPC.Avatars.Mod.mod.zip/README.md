# NPC头像图标增添mod

---

[**【English edition】**](https://github.com/Eudemonism00/DOL-npcicon-mods/blob/main/README-EN.md)

[**【GitHub仓库】**](https://github.com/Eudemonism00/DOL-npc-avatars-mod)

---

## 内容介绍

安装后社交栏会有角色小头像，表情跟随态度文本变化，部分角色有不同性别或造型的差分。

游戏并未给出角色的具体样貌，头像为本模组的二次创作，请不要将其误认为是官方形象。

模组（包括图片和代码）在DoL相关范围内自由使用，可二改二转；如果你想做一个类似功能也没问题，不需要问我。如果要二改或整合，请务必保留“图像说明”部分，或者在游戏内其他地方标注。

> 图像说明：您已使用NPC头像增添模组。游戏作者并未提供各位角色的具体形象，头像为模组二次创作，仅供爱好者交流，请勿将其当作官方形象。

## 使用说明

### 版本说明

- NPC Avatars Mod：可单独加载无需简易框架，如果SF版出现问题则选择该版本
- ~~NPC Avatars Mod (SF)：简易框架版~~

**简易框架已不适配新版游戏，请不要下载SF版，直接下最新的无需框架的版本**

### 必须下载

- NPC Avatars Mod *（mod本体，点击右边release下载）*
- 带有Modloader的游戏本体 *（用于加载mod）*
- ~~Simple Frameworks （前置）~~
- ~~NPC Avatars Mod (SF) （mod本体，点击右边release下载）~~

### 加载顺序

~~首先加载简易框架（Simple Frameworks），再加载NPC Avatars Mod (SF)。~~

如果你使用普通版，直接加载NPC Avatars Mod，不需要简易框架。

## 问题反馈

反馈群：832410983

Discord：Eudemonism00
